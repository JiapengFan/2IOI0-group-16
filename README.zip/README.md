# 2IOI0-group-16

### Instruction virtual/python environment
Set up your own environment in the desired directory using: *py -m venv .venv*

Install libraries using pip: *pip install ...*

Add library to Python environment: *pip freeze > requirements.txt*.

Install Python environment: *pip install -r requirements.txt*.
